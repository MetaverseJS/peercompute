# ULG-Star Runtime Spec v0.3

**Universal Law Graph runtime for emergent star, plasma, material, and first-principles property simulation on PeerCompute + WebGPU compute workers**  
**Draft:** 0.3  
**Date:** 2026-06-05  
**Status:** Architecture/specification draft, not a validated physics code.

---

## 0. What changed from v0.2

The v0.2 spec made the correct architectural move — **material properties should not be primitive** — but it over-compressed the physical foundations. The phrase “the rest should emerge” was too strong unless the substrate contains the layers from which the named behavior can actually emerge.

This v0.3 spec keeps the minimal law-graph runtime, but adds the missing first-class foundations:

```text
1. Quantum statistical mechanics
2. Relativistic and QED regime support
3. General-relativistic gravity regime support
4. Irreversibility/coarse-graining/decoherence contracts
5. Strong-correlation fallbacks beyond ordinary DFT
6. Nuclear + weak interaction provenance for fusion and neutrinos
7. Symmetry/action-derived invariants, not merely after-the-fact bookkeeping
8. Explicit validity envelopes so nonrelativistic/mean-field shortcuts cannot silently claim universality
```

The corrected rule is:

> **No named material property is primitive.**  
> A property is a cached response function derived from a microscopic state, a statistical ensemble, and a declared coarse-graining/validity contract.

A second rule is now explicit:

> **No phenomenon is allowed to “emerge” unless the graph contains the physical substrate that can generate it.**

For example:

```text
Opacity does not emerge from a static Coulomb potential alone.
It needs matter-photon coupling, quantum transition strengths, populations, and line/scattering models.

Degeneracy pressure does not emerge from a single wavefunction observer.
It needs Fermi-Dirac statistics and an ensemble/free-energy layer.

Black holes do not emerge from Newtonian gravity.
They require a general-relativistic spacetime/metric layer.

Dissipation does not emerge from reversible microscopic laws unless the coarse-graining assumption is declared.
```

---

## 1. Design thesis

ULG is not a pile of named solvers such as `FluidSolver`, `CrystalSolver`, `StarSolver`, and `MaterialSolver`.

ULG is a small generative runtime:

```text
carrier state
  -> metric / neighborhood
  -> edge interaction messages
  -> message accumulation
  -> structure-preserving integration
  -> invariant / constraint projection
  -> coarse-grain observation
  -> topology / phase / refinement events
  -> updated carrier state
```

Named laws appear as behavior observed from repeated graph evolution.

![ULG v0.3 Minimal Generative Substrate](diagrams/diagram_01_minimal_generative_substrate.jpg)

The code-volume rule remains:

```text
New phenomenon = state channel
               + interaction term
               + observer
               + event/refinement trigger
```

But v0.3 adds a foundation rule:

```text
New physical regime = declared root contract
                    + validity envelope
                    + bridge into the carrier graph
```

The root contracts are:

```text
Symmetry / action
Quantum state
Quantum statistical ensemble
Fields / gauge / radiation
Nuclear / weak interactions
Spacetime / gravity
Coarse-graining / decoherence
Validation / provenance
```

These are not meant to become giant monolithic modules. They are contracts that every law term must satisfy or explicitly opt out of.

---

## 2. Runtime deployment target

The runtime target is PeerCompute using WebGPU compute workers.

The intended split is:

```text
TypeScript / JavaScript:
  graph orchestration
  validity checks
  scale activation
  PeerCompute task capsules
  work distribution
  state deltas
  provenance metadata

WebGPU / WGSL compute workers:
  dense numeric kernels
  neighbor construction
  particle and field updates
  reductions
  stencils
  sparse matrix-vector passes
  local eigensolver pieces
  reaction/radiation table interpolation
  constraint projection

WASM / CPU fallback:
  f64 reference solves
  stiff small systems
  high-precision reductions
  exact small quantum tasks
  validation audits
```

![PeerCompute + WebGPU Compute Worker Runtime](diagrams/diagram_02_peercompute_webgpu_runtime.jpg)

A ULG worker should not traverse an arbitrary object graph inside WGSL. The graph compiler emits compact pass plans over flat buffers.

Example WebGPU pass families:

```text
buildSpatialHash
buildNeighborEdges
evaluateEdgeMessages
accumulateNodeMessages
integrateState
projectConstraints
observeCoarseFields
updateTopologyEvents
sparseMatVec
localReduction
prefixScan
interpolateClosureTable
packPeerDelta
```

---

## 3. Corrected foundation: emergence is conditional

The central mistake to avoid is thinking that one microscopic equation automatically produces all usable macroscopic physics.

The corrected model is:

```text
microscopic primitive
  + statistical ensemble
  + field coupling
  + coarse-graining rule
  + validity envelope
  + numerical solver
  = usable emergent closure
```

The runtime should distinguish three classes of claims:

### 3.1 Actually emergent inside the active substrate

Example:

```text
local repulsion + cohesion + thermal motion + coarse-graining
  -> liquid-like density, surface, and pressure behavior
```

### 3.2 Derived from a lower-scale first-principles task and cached

Example:

```text
nuclei + electrons + boundary conditions
  -> quantum/electronic calculation
  -> ensemble response
  -> dielectric tensor / opacity / elastic tensor
  -> cached carrier closure
```

### 3.3 Imported approximation with provenance

Example:

```text
stellar nuclear reaction rate table
  -> allowed only if tagged with nuclear/weak provenance,
     interpolation range, uncertainty, and invalidation triggers
```

The runtime must never label case 3 as “fully emergent.”

---

## 4. Universal carrier graph

A carrier is a sample of physical state. It may represent an atom, molecule, SPH-like fluid parcel, plasma parcel, star macro-particle, radiation packet, field sample, grain node, or quantum coefficient block.

```ts
export interface CarrierState {
  id: number;

  // Mechanics
  x: Vec3;                 // local-frame position
  p: Vec3;                 // momentum
  massEnergy: number;      // rest mass + tracked internal contribution when applicable

  // Composition / identity
  species?: SpeciesVector; // isotope, ion, molecule, particle species populations
  charge?: number;
  baryonNumber?: number;
  leptonNumber?: number;

  // Thermal / ensemble state
  internalEnergy?: number;
  entropy?: number;
  temperature?: number;    // observer/closure result, not primitive truth
  chemicalPotential?: Float32Array;
  degeneracyParameter?: number;

  // EM / plasma
  electricField?: Vec3;
  magneticField?: Vec3;
  vectorPotential?: Vec3;
  conductivity?: number;
  resistivity?: number;
  ionizationFraction?: number;

  // Material / topology
  phaseOrder?: number;
  localOrder?: number;
  bondTopologyRef?: number;
  damage?: number;
  latent?: Float32Array;

  // Relativity / frame
  frameId: string;
  fourVelocity?: Vec4;
  metricRef?: number;

  // Provenance
  closureRefs?: ClosureRef[];
  validityFlags: number;
}
```

A carrier is not required to be a literal particle. At star scale, a carrier is usually a macro-sample of plasma whose thermodynamic and nuclear behavior is derived from ensemble closures.

---

## 5. Minimal pass loop

A ULG tick is:

```text
1. Load active domains and local coordinate frames.
2. Build or update neighborhoods / interaction edges.
3. Evaluate coarse observers needed for activation.
4. Select active law terms by validity envelope.
5. Run edge-message kernels and field kernels.
6. Accumulate messages to carrier or grid state.
7. Run local reaction/radiation/statistical updates.
8. Integrate state with structure-preserving methods.
9. Project constraints or clean fields when needed.
10. Recompute residuals and invariants.
11. Trigger refinement, coarsening, or regime switching.
12. Commit compact PeerCompute deltas with provenance.
```

The pass loop is small. The behavior space is large.

---

## 6. First-principles atomic/material layer

For ordinary material properties, the root source is the quantum problem of nuclei and electrons.

The allowed primitive material inputs are:

```text
nuclear species / isotope
nuclear charge
nuclear mass
nuclear spin when relevant
nuclear positions or distribution
electron count / charge state
electron spin state / spin constraints
fundamental constants
external fields
boundary conditions
```

Everything below is derived, cached, or observed:

```text
bonding
bond order
charge transfer
forces
stress
phonons
heat capacity
thermal conductivity
electrical conductivity
optical absorption
refractive index
magnetism
surface energy
friction
viscosity
phase stability
elastic tensor
plastic flow response
fracture toughness
diffusion coefficients
chemical reaction barriers
opacity coefficients
```

![First-Principles Atomic Pipeline](diagrams/diagram_03_first_principles_atomic_pipeline.jpg)

### 6.1 Hamiltonian contract

```ts
export interface HamiltonianSpec {
  id: string;

  nuclei: NuclearSite[];
  electrons: ElectronSpec;
  boundary: BoundaryConditionSpec;
  externalFields?: ExternalFieldSpec;

  tier:
    | "exact_many_body_small"
    | "nonrelativistic_coulomb"
    | "born_oppenheimer"
    | "kohn_sham_dft"
    | "finite_temperature_dft"
    | "density_functional_perturbation"
    | "time_dependent_dft"
    | "hartree_fock_or_post_hf"
    | "tight_binding"
    | "quantum_monte_carlo"
    | "dmrg"
    | "dmft"
    | "quantum_derived_ml";

  relativisticTreatment:
    | "none"
    | "pauli"
    | "scalar_relativistic"
    | "spin_orbit"
    | "dirac"
    | "breit_pauli"
    | "qed_response_required";

  basis?: BasisSpec;
  pseudopotential?: PseudopotentialSpec;
  exchangeCorrelation?: string;
  kPointMesh?: KPointMeshSpec;
  convergence: ConvergenceSpec;
  units: UnitSystem;
}

export interface NuclearSite {
  Z: number;
  isotopeMass: number;
  position: Vec3;
  spin?: number;
}

export interface ElectronSpec {
  count: number;
  totalCharge: number;
  spinMultiplicity?: number;
  temperature?: number;
  chemicalPotential?: number;
}
```

The basic nonrelativistic molecular Hamiltonian is:

```text
H = T_e + T_n + V_ee + V_nn + V_en + V_ext
```

Where:

```text
T_e   electron kinetic energy
T_n   nuclear kinetic energy
V_ee  electron-electron Coulomb interaction
V_nn  nucleus-nucleus Coulomb interaction
V_en  electron-nucleus Coulomb attraction
V_ext external fields and boundary terms
```

In Born-Oppenheimer mode, nuclei are parameters for the electronic solve:

```text
H_e(r; R) ψ_k(r; R) = E_k(R) ψ_k(r; R)
```

The potential energy surface `E(R)` drives nuclear forces and atomistic evolution.

### 6.2 Quantum output contract

```ts
export interface QuantumStateResult {
  taskId: string;
  hamiltonianHash: string;
  method: HamiltonianSpec["tier"];

  totalEnergy?: number;
  freeEnergy?: number;
  grandPotential?: number;

  electronDensity?: Field3DRef;
  orbitals?: OrbitalSetRef;
  manyBodyStateRef?: string;
  chargeDensity?: Field3DRef;
  spinDensity?: Field3DRef;

  forces?: Float64Array;       // -dE/dR, or approximate equivalent
  stressTensor?: Mat3;

  bandStructure?: BandStructureRef;
  densityOfStates?: DensityOfStatesRef;
  phonons?: PhononResultRef;
  dielectricTensor?: FrequencyTensorRef;
  polarizability?: TensorRef;
  transitionMatrixElements?: TransitionSetRef;
  spectralFunction?: SpectralFunctionRef;

  convergence: ConvergenceReport;
  uncertainty: UncertaintyModel;
  validity: ValidityEnvelope;
}
```

### 6.3 Response-closure rule

A material closure is not valid unless it can answer:

```text
Derived from what Hamiltonian?
Solved with what method?
At what thermodynamic ensemble?
At what composition, density, pressure, temperature, phase, and field range?
With what convergence and uncertainty?
What invalidates it?
```

```ts
export interface ResponseClosure<T> {
  id: string;
  quantity:
    | "equation_of_state"
    | "elastic_tensor"
    | "phonon_spectrum"
    | "heat_capacity"
    | "thermal_conductivity"
    | "electrical_conductivity"
    | "dielectric_tensor"
    | "optical_absorption"
    | "opacity"
    | "surface_energy"
    | "viscosity"
    | "diffusion"
    | "reaction_barrier"
    | "magnetization"
    | "magnetic_susceptibility"
    | "interatomic_potential";

  value: T;
  independentVariables: StateChannel[];

  provenance: {
    hamiltonianHashes: string[];
    quantumTaskIds: string[];
    ensembleTaskIds?: string[];
    coarseGrainTaskIds?: string[];
    method: string;
    assumptions: string[];
    convergence: ConvergenceReport;
    uncertainty: UncertaintyModel;
  };

  validity: ValidityEnvelope;
  invalidationTriggers: TriggerSpec[];
}
```

---

## 7. Quantum statistical mechanics layer

This is the most important v0.3 fix.

A star, liquid, plasma, or solid at finite temperature is not represented by one pure wavefunction. It is represented by an ensemble or density matrix.

A single quantum solve may produce:

```text
energy levels
states
bands
density of states
transition strengths
phonons
scattering amplitudes
```

But macroscopic observables require:

```text
occupancy distributions
partition functions
chemical potentials
free energy derivatives
transport correlation functions
population kinetics
```

![Quantum Statistical Bridge](diagrams/diagram_04_quantum_statistical_bridge.jpg)

### 7.1 Ensemble contract

```ts
export interface EnsembleSpec {
  id: string;
  quantumResultRefs: string[];

  ensemble:
    | "microcanonical"
    | "canonical"
    | "grand_canonical"
    | "local_thermal_equilibrium"
    | "non_lte_collisional_radiative"
    | "degenerate_fermi_gas"
    | "bosonic_field";

  temperature?: number;
  volume?: number;
  particleNumbers?: Record<string, number>;
  chemicalPotentials?: Record<string, number>;
  density?: number;

  statistics: {
    electrons: "fermi_dirac";
    ions?: "maxwell_boltzmann" | "fermi_dirac" | "bose_einstein";
    photons?: "bose_einstein" | "radiation_transport_packets";
    phonons?: "bose_einstein";
  };

  assumptions: string[];
  validity: ValidityEnvelope;
}
```

### 7.2 Thermodynamic closure

```ts
export interface ThermodynamicClosure {
  id: string;
  ensembleHash: string;

  freeEnergy?: number;
  grandPotential?: number;
  entropy?: number;
  internalEnergy?: number;
  pressure?: number;
  chemicalPotential?: Record<string, number>;
  heatCapacity?: number;
  compressibility?: number;
  degeneracyPressure?: number;
  ionizationFractions?: Record<string, number>;

  equationOfStateRef?: string;
  opacityRef?: string;
  transportRef?: string;

  uncertainty: UncertaintyModel;
  validity: ValidityEnvelope;
}
```

The pressure closure should come from a free-energy derivative, not from an arbitrary constant:

```text
P = - (∂F / ∂V)_{T,N}
```

Entropy comes from:

```text
S = - (∂F / ∂T)_{V,N}
```

Heat capacity comes from:

```text
C_V = (∂U / ∂T)_{V,N}
```

Chemical potential comes from:

```text
μ_i = (∂F / ∂N_i)_{T,V,N_j}
```

Electron degeneracy pressure requires Fermi-Dirac statistics. It is not optional for white dwarfs, dense stellar cores, or highly compressed matter.

### 7.3 Ionization and Saha/non-LTE handling

At local thermodynamic equilibrium, ionization balance can be derived from chemical-potential equality and partition functions. For simple hydrogen-like equilibrium, the Saha-style structure is:

```text
neutral H + energy ⇌ proton + electron
```

The implementation should support:

```text
LTE Saha ionization
pressure ionization corrections
continuum lowering
partial degeneracy corrections
non-LTE collisional-radiative population kinetics
```

The selector is:

```text
if local thermal equilibrium valid:
    use LTE/Saha-like closure
else:
    use collisional-radiative population model
```

A carrier must not simply store `ionization = f(T)` without provenance.

---

## 8. Deriving material properties from first principles

The system should derive material properties as response functions.

### 8.1 Property derivation map

```text
Energy surface E(R)
  -> forces
  -> equilibrium geometry
  -> bond stiffness
  -> phonons

Free energy F(T,V,N,strain,field)
  -> pressure
  -> entropy
  -> heat capacity
  -> elastic tensor
  -> phase stability

Transition matrix elements + populations
  -> opacity
  -> emissivity
  -> optical absorption
  -> spontaneous/stimulated emission closures

Correlation functions
  -> viscosity
  -> thermal conductivity
  -> electrical conductivity
  -> diffusion

Spin/electronic response
  -> magnetization
  -> susceptibility
  -> exchange constants
  -> spin-orbit effects
```

### 8.2 Examples

```text
elastic tensor:
  C_ijkl = ∂²F / ∂ε_ij ∂ε_kl

pressure:
  P = -∂F/∂V

surface energy:
  γ = (F_surface - F_bulk_reference) / area

thermal expansion:
  α = response of equilibrium volume/strain to T

optical response:
  dielectric tensor ε(ω) from electronic/phonon response and transition strengths

conductivity:
  Kubo / Kubo-Greenwood / Boltzmann transport from states and scattering

viscosity:
  stress autocorrelation or nonequilibrium response

diffusion:
  mean-squared displacement, transition state theory, or hopping barriers

opacity:
  populations + bound-bound + bound-free + free-free + scattering cross sections + line broadening
```

### 8.3 No material labels as source of truth

The following is invalid as source data:

```json
{
  "material": "steel",
  "youngsModulus": 200000000000,
  "conductivity": 6000000
}
```

This is valid as a human label over derived state:

```json
{
  "label": "low-carbon steel-like polycrystal",
  "composition": { "Fe56": 0.982, "C12": 0.004, "Mn55": 0.01, "Si28": 0.004 },
  "microstructure": "ferrite_pearlite_polycrystal_cache_42",
  "propertyClosures": [
    "closure.elastic_tensor.fe_c_polycrystal.v12",
    "closure.thermal_conductivity.fe_c_polycrystal.v08",
    "closure.optical_response.oxidized_surface.v03"
  ]
}
```

The label helps humans. The closures drive physics.

---

## 9. Strong-correlation and many-body failure handling

Ordinary Kohn-Sham DFT is useful, but it is not a universal solution for all emergent material behavior.

ULG must detect when mean-field-ish assumptions are unsafe.

```ts
export interface CorrelationRiskReport {
  risk: "low" | "medium" | "high" | "invalid";
  indicators: string[];
  suggestedTier:
    | "hybrid_functional"
    | "dft_plus_u"
    | "gw_bse"
    | "dmft"
    | "dmrg"
    | "quantum_monte_carlo"
    | "exact_diagonalization_small_cluster";
}
```

Triggers include:

```text
partially filled localized orbitals
large U/t estimate
unstable magnetic order
fractional occupations that change qualitatively with method
incorrect metal/insulator classification
large self-interaction error warning
known Mott/charge-transfer/heavy-fermion/fractional Hall regime
strong entanglement indicator
```

If no adequate solver tier is available, ULG must mark the closure as invalid or low-confidence. It must not pretend ordinary DFT produced first-principles truth.

---

## 10. Relativistic, QED, and radiation layer

The v0.2 nonrelativistic Coulomb Hamiltonian is a useful material baseline, but it is not enough for heavy elements, high fields, opacity, magnetars, compact stars, or energetic plasmas.

![Relativistic / QED / GR Regime Ladder](diagrams/diagram_07_regime_ladder_relativistic_qed_gr.jpg)

### 10.1 Relativistic electronic corrections

The quantum stack must support relativistic tiers:

```text
Pauli Hamiltonian:
  spin and magnetic coupling in weakly relativistic limit

scalar-relativistic corrections:
  mass-velocity and Darwin-like corrections

spin-orbit coupling:
  necessary for heavy elements, fine structure, magnetic anisotropy, topological bands

Dirac-based treatment:
  required when fully relativistic electronic structure matters

Breit / QED-response corrections:
  high-Z or extreme-field corrections
```

A closure involving optical spectra, magnetism, heavy elements, or strong fields must declare whether spin-orbit and relativistic corrections are included.

### 10.2 Radiation is not just classical Maxwell

Classical Maxwell fields are valid for many plasma-scale field updates. They do not by themselves derive quantum emission/absorption line physics.

ULG should use two linked layers:

```text
Classical field / radiation transport layer:
  Maxwell, MHD, radiation packets, diffusion, ray/packet transport

Quantum matter-radiation response layer:
  transition matrix elements, oscillator strengths, spontaneous/stimulated emission,
  photoionization, bremsstrahlung, scattering, pair thresholds when relevant
```

Opacity closure must be derived from:

```text
species populations
level populations
transition strengths
photoionization cross sections
free-free processes
scattering
line broadening
plasma corrections
radiation field state
```

Not from:

```text
material.opacity = constant
```

### 10.3 QED and extreme-field triggers

For magnetar-like fields, pair plasmas, or intense photon fields, ULG must escalate.

Selectors:

```text
B / B_QED approaches significant fraction
photon energy near pair production threshold
kT near relativistic electron scale
high optical depth + high compactness
radiation pressure dominates gas pressure
```

Activated closures may include:

```text
Compton / inverse Compton scattering
synchrotron / curvature radiation
cyclotron processes
pair production / annihilation
vacuum polarization approximations
strong-field opacity corrections
```

---

## 11. Spacetime and gravity layer

Newtonian gravity is a limit, not the deepest gravity contract.

The graph should support tiers:

```text
G0_newtonian:
  particle-particle, tree, particle-mesh, multipole gravity

G1_post_newtonian:
  weak-field relativistic corrections, compact binaries, precision orbits

G2_tov_static_compact_star:
  spherical relativistic hydrostatic structure for neutron-star/compact-core tests

G3_fixed_metric_gr:
  matter/radiation evolving in a prescribed curved spacetime

G4_grmhd_dynamic_or_approx:
  relativistic plasma and radiation in curved spacetime; black-hole/magnetar contexts
```

```ts
export interface GravityRegimeSelector {
  compactness: number;        // GM/(Rc^2) or local equivalent
  maxVelocityOverC: number;
  gravitationalRedshiftRisk: number;
  curvatureGradient: number;
  requiresMetric: boolean;
}
```

Rules:

```text
main-sequence star:
  Newtonian or weak relativistic correction usually acceptable

white dwarf near Chandrasekhar regime:
  relativistic degeneracy EOS required; gravity may still often be Newtonian-ish but must be checked

neutron star:
  TOV/GR required

black hole / magnetar near black hole:
  GRMHD or fixed-metric GR radiation/plasma layer required

cosmology:
  metric/expansion layer required
```

The engine must not claim black-hole behavior emerges from Newtonian gravity.

---

## 12. Nuclear and weak interaction layer

Fusion does not come from the electronic Coulomb Hamiltonian. It requires nuclear physics and, for the proton-proton chain, weak interaction physics.

```ts
export interface NuclearReactionNetworkSpec {
  id: string;
  species: NuclearSpecies[];
  reactions: ReactionChannel[];

  provenance:
    | "ab_initio_nuclear_small"
    | "effective_nuclear_model"
    | "evaluated_rate_table"
    | "experimental_fit"
    | "screened_plasma_rate";

  includesWeakProcesses: boolean;
  includesNeutrinoLosses: boolean;
  screeningModel?: string;
  validity: ValidityEnvelope;
}

export interface ReactionChannel {
  reactants: SpeciesVector;
  products: SpeciesVector;
  qValue: number;
  rateLawRef: string;
  emits?: ("gamma" | "neutrino" | "positron" | "electron")[];
  conserves: ("charge" | "baryon" | "lepton" | "energy_momentum")[];
}
```

Examples:

```text
proton + proton -> deuteron + positron + electron neutrino
  weak interaction required

CNO cycle reactions
  nuclear reaction network + beta decays where applicable

triple-alpha
  nuclear resonance data required

advanced burning / collapse
  electron capture, beta decay, neutrino cooling required
```

Fusion kernel output:

```text
Δspecies
ΔinternalEnergy
ΔradiationEnergy
ΔneutrinoLoss
ΔelectronFraction Y_e
uncertainty
validity report
```

The nuclear layer is first-principles only when the nuclear Hamiltonian or effective nuclear model and weak interaction terms are included. Otherwise, it is an imported closure with explicit provenance.

---

## 13. Irreversibility, decoherence, and coarse-graining

The base microscopic equations are mostly reversible. Dissipation, diffusion, shock heating, viscosity, radiative cooling, and thermalization require coarse-graining assumptions.

ULG must make those assumptions explicit.

![Irreversibility and Decoherence Boundary](diagrams/diagram_08_irreversibility_decoherence_closure.jpg)

### 13.1 Closure assumption contract

```ts
export interface CoarseGrainingAssumption {
  id: string;
  kind:
    | "molecular_chaos"
    | "local_thermal_equilibrium"
    | "markovian_bath"
    | "radiation_escape"
    | "unresolved_turbulence"
    | "ensemble_average"
    | "decoherence_to_classical"
    | "stochastic_thermostat";

  hiddenVariables: string[];
  discardedCorrelations: string[];
  entropyAccounting: "explicit" | "estimated" | "external_sink";
  fluctuationDissipationCheck?: string;
  validity: ValidityEnvelope;
}
```

Any dissipative kernel must reference one of these assumptions.

Bad:

```ts
dissipativeFlux(state) // no provenance
```

Good:

```ts
dissipativeFlux(state, closureAssumptionRef="local_thermal_equilibrium.v3")
```

### 13.2 Entropy budget

Every irreversible closure should emit:

```ts
export interface EntropyReport {
  deltaResolvedEntropy: number;
  deltaHiddenEntropy: number;
  exportedEntropy: number;
  productionRate: number;
  secondLawStatus: "ok" | "warn" | "invalid";
}
```

The system is allowed to model irreversible behavior. It is not allowed to pretend irreversibility was derived without a coarse-graining choice.

### 13.3 Quantum-to-classical boundary

ULG mixes quantum closures and classical carriers operationally. The boundary must be explicit.

```ts
export interface QuantumClassicalBridge {
  id: string;
  quantumInputRefs: string[];
  classicalOutputRefs: string[];

  method:
    | "born_oppenheimer_surface"
    | "wigner_sampling"
    | "decohered_density_matrix"
    | "thermal_ensemble_average"
    | "trajectory_surface_hopping"
    | "measurement_like_projection_for_observer_only";

  decoherenceTimescale?: number;
  assumptions: string[];
  validity: ValidityEnvelope;
}
```

This does not solve the measurement problem. It declares the operational approximation used by the simulator.

---

## 14. Symmetry and invariants

Conservation laws should be built from symmetry/action declarations wherever possible.

```ts
export interface ActionLawTerm {
  id: string;
  fields: StateChannel[];
  lagrangianDensity?: string;
  hamiltonianDensity?: string;
  discreteAction?: KernelSpec;

  symmetries: SymmetrySpec[];
  derivedInvariants: InvariantSpec[];
  numericalIntegrator: "symplectic" | "variational" | "projection" | "operator_split";
}

export interface SymmetrySpec {
  group:
    | "time_translation"
    | "space_translation"
    | "rotation"
    | "gauge_u1"
    | "lorentz"
    | "diffeomorphism"
    | "permutation"
    | "particle_exchange";

  actsOn: StateChannel[];
  expectedConservedQuantity?: string;
  brokenBy?: string[];
}
```

Validation still exists, but it is not the source of conservation. It catches numerical drift and invalid approximations.

Examples:

```text
time translation symmetry -> energy conservation where closed and valid
space translation symmetry -> momentum conservation
rotation symmetry -> angular momentum conservation
gauge symmetry -> charge conservation / field constraints
particle exchange symmetry -> quantum statistics constraints
diffeomorphism symmetry -> stress-energy conservation in GR context
```

---

## 15. Liquids and SPH-like emergence

ULG should not make Navier-Stokes the primitive liquid law.

Liquid behavior should come from carrier interactions and coarse-grained observers:

```text
short-range repulsion
medium-range cohesion
thermal ensemble state
dissipative momentum exchange with declared coarse-graining
local density/free-energy response
surface-energy response
topology/phase events
```

Then observers compute:

```text
density
pressure-like response
velocity field
temperature
surface normal
surface tension-like behavior
viscosity-like transport
phase fraction
```

At large scale, Navier-Stokes-like behavior may be an observed continuum approximation. It is not the low-level primitive.

The fluid pass set is:

```text
buildNeighborEdges
estimateDensity
computeFreeEnergyGradientMessages
computeThermalExchange
computeDissipativePairExchange
accumulateMessages
integrateCarriers
observeContinuumFields
updatePhaseEvents
```

---

## 16. Star from hydrogen: activation path

A star should not be hardcoded. It should appear when a large hydrogen carrier graph self-gravitates, heats, ionizes, fuses, radiates, and reaches a dynamic balance.

![Emergent Star from Hydrogen](diagrams/diagram_05_star_from_hydrogen_activation.jpg)

### 16.1 Initial state

```ts
export interface HydrogenCloudInit {
  totalMass: number;
  radius: number;
  carrierCount: number;
  composition: {
    H1: number;
    H2?: number;
    He4?: number;
    metals?: number;
  };
  initialTemperature: number;
  angularMomentum?: Vec3;
  seedMagneticField?: Vec3 | "battery_allowed";
  perturbationSpectrum?: string;
}
```

### 16.2 Active terms by state

```text
Cold neutral cloud:
  gravity
  carrier motion
  gas-like thermal response
  cooling closure if radiating

Compressing cloud:
  gravity
  thermal ensemble update
  pressure/free-energy response
  shock/dissipation closure

Hot partially ionized cloud:
  ionization population model
  plasma conductivity
  radiation opacity
  magnetic induction if seed/battery exists

Dense hot core:
  nuclear reaction network
  weak interaction pp chain where applicable
  radiation/neutrino energy handling

Stellar state:
  pressure/radiation support
  convection/mixing observer
  radiative transport
  magnetic dynamo if plasma motion sustains it
```

### 16.3 Minimal star timestep

```text
1. Build gravitational hierarchy and local neighborhoods.
2. Observe density, velocity gradients, temperature, degeneracy, ionization risk.
3. Activate thermodynamic ensemble closures.
4. Apply self-gravity and compression response.
5. Apply thermal/radiation transport.
6. Activate fusion network only where density/temperature/composition valid.
7. Apply neutrino/radiation energy losses.
8. Activate plasma/MHD terms where ionized/conductive.
9. Integrate carriers.
10. Validate mass, charge, baryon number, lepton accounting, energy budget, ∇·B.
11. Refine core, shocks, surface/photosphere, nuclear burning regions, and magnetic reconnection zones.
12. Commit compact PeerCompute deltas.
```

---

## 17. Emergent stellar magnetic field / dynamo

A star’s magnetic field should not be assigned as a property. It should emerge from ionized plasma motion, current formation, rotation, convection, induction, a seed/battery source, and Lorentz-force backreaction.

![Emergent Stellar Dynamo Layer](diagrams/diagram_06_emergent_stellar_dynamo.jpg)

### 17.1 Minimum magnetic substrate

```text
ionization / mobile charge carriers
velocity field / carrier motion
conductivity and resistivity closures
magnetic field B or vector potential A
induction update
Lorentz force backreaction
divergence-free constraint
seed field or battery source
```

### 17.2 Zero-field warning

If the simulation starts with exactly zero magnetic field and has no battery source, ideal/resistive MHD will keep the field at zero. To grow a stellar field, ULG needs either:

```text
tiny seed magnetic field
or
battery term from plasma gradients / charge separation
```

### 17.3 Magnetic pass loop

```text
1. Observe ionization, conductivity, resistivity.
2. Observe rotation, shear, and convection.
3. Generate seed field where battery conditions are valid.
4. Evolve B or A through induction.
5. Clean/project ∇·B.
6. Compute Lorentz force and magnetic pressure/tension.
7. Feed back into carrier motion and energy.
8. Track magnetic energy growth/saturation.
9. Trigger refinement in reconnection/high-current regions.
```

```ts
export interface MagneticFieldClosure {
  fieldRepresentation: "B" | "vector_potential_A" | "hybrid";
  inductionKernelRef: string;
  divergenceControl:
    | "projection"
    | "hyperbolic_cleaning"
    | "constrained_transport_like"
    | "vector_potential_identity";
  seedPolicy: "explicit_seed" | "battery_allowed" | "none";
  lorentzBackreaction: boolean;
  validity: ValidityEnvelope;
}
```

---

## 18. Opacity and optical behavior

Optical properties and stellar opacity are derived response functions, but they need more than a ground-state Schrödinger solve.

Required inputs:

```text
electronic states / bands / levels
transition matrix elements
population distribution
line broadening model
photoionization/free-free/scattering processes
radiation field state
density/temperature/composition
plasma corrections
magnetic-field corrections when relevant
```

Material optical closure:

```ts
export interface OpticalClosure {
  dielectricTensorRef?: string;
  absorptionSpectrumRef?: string;
  scatteringModelRef?: string;
  refractiveIndexModelRef?: string;
  emissivityModelRef?: string;
  sourceQuantumTasks: string[];
  ensembleRef: string;
  validity: ValidityEnvelope;
}
```

Stellar opacity closure:

```ts
export interface OpacityClosure {
  rosselandMean?: ClosureTableRef;
  planckMean?: ClosureTableRef;
  monochromaticOpacity?: ClosureTableRef;

  mechanisms: (
    | "electron_scattering"
    | "bound_bound"
    | "bound_free"
    | "free_free"
    | "molecular"
    | "dust"
    | "pair_process"
    | "cyclotron_synchrotron"
  )[];

  populationModelRef: string;
  quantumTransitionRefs: string[];
  lineBroadeningModel?: string;
  validity: ValidityEnvelope;
}
```

---

## 19. Regime activation and validity envelopes

Every law term and closure must declare where it is valid.

```ts
export interface ValidityEnvelope {
  lengthScale?: Range;
  timeScale?: Range;
  temperature?: Range;
  density?: Range;
  pressure?: Range;
  magneticField?: Range;
  electricField?: Range;
  velocityOverC?: Range;
  compactness?: Range;
  degeneracyParameter?: Range;
  ionizationFraction?: Range;
  opticalDepth?: Range;
  composition?: CompositionRange;
  phaseRegion?: string[];
  assumptions: string[];
}
```

Regime selectors:

```text
v/c high:
  activate special relativity / relativistic kinetic corrections

GM/(Rc²) high:
  activate post-Newtonian, TOV, or GRMHD layer

electron degeneracy high:
  activate Fermi-Dirac ensemble and degeneracy pressure

B/B_QED high:
  activate strong-field QED warning/closure

non-LTE risk high:
  replace Saha/LTE with collisional-radiative populations

strong-correlation risk high:
  replace ordinary DFT closure with correlated solver tier or invalidate

shock / high gradient:
  refine carriers and activate entropy-producing closure

new bond topology:
  activate atomistic/quantum refinement
```

No silent extrapolation.

---

## 20. PeerCompute task capsule

```ts
export interface LawTaskCapsule {
  taskId: string;
  graphId: string;
  domainId: string;
  scaleBand:
    | "Q0_ELECTRONIC"
    | "Q1_ATOMISTIC"
    | "S0_STATISTICAL"
    | "M0_MESOSCALE"
    | "C0_CONTINUUM_CARRIER"
    | "P0_PLASMA_STELLAR"
    | "R0_RADIATION"
    | "N0_NUCLEAR"
    | "G0_GRAVITY_NEWTONIAN"
    | "G1_GR_RELATIVISTIC";

  timestep: number;
  dt: number;

  lawNodes: string[];
  closureRefs: string[];
  kernelPasses: KernelPassSpec[];

  inputRefs: StateRef[];
  outputRefs: StateRef[];
  boundaryRefs: StateRef[];
  requiredHaloDepth: number;

  seed: string;
  unitsHash: string;
  symmetryHash?: string;
  lawHash: string;
  inputStateHash: string;

  tolerance: {
    absolute: number;
    relative: number;
    invariantDrift: number;
    entropyBudget?: number;
  };

  validator: ValidatorSpec;
  commitPolicy: "authoritative" | "quorum" | "optimistic" | "local_only";
}
```

Task result:

```ts
export interface LawTaskResult {
  taskId: string;
  outputStateHash: string;
  delta: CompactDelta;
  residuals: ResidualReport;
  invariants: InvariantReport;
  entropy?: EntropyReport;
  uncertainty: UncertaintyReport;
  provenance: ProvenanceReport;
  events: PhysicsEvent[];
  performance: KernelTimingReport;
}
```

---

## 21. WebGPU precision model

WebGPU compute workers should assume portable `f32`-centered shader math unless a platform extension or fallback is declared.

Precision modes:

```ts
export type PrecisionMode =
  | "f16_approx"
  | "f32"
  | "mixed_f16_f32"
  | "compensated_f32"
  | "double_double_f32"
  | "fixed_point_scaled_integer"
  | "wasm_f64"
  | "cpu_reference_f64";
```

Use:

```text
f32:
  particle updates, local fields, visualization, many approximate kernels

compensated f32:
  energy/momentum reductions, long sums, residuals

double-double / scaled coordinates:
  large astronomical dynamic range, long orbital integrations

WASM/CPU f64:
  reference validation, exact small quantum tasks, stiff small solves
```

Never store atoms and gigaparsec coordinates in one raw coordinate frame. Use nested local coordinate charts.

```text
cosmological frame
  -> galaxy frame
    -> star frame
      -> plasma domain frame
        -> material patch frame
          -> atomic frame
```

---

## 22. Data layout

Use struct-of-arrays buffers for WebGPU.

```text
pos_x[] pos_y[] pos_z[]
momentum_x[] momentum_y[] momentum_z[]
massEnergy[]
speciesOffset[] speciesData[]
internalEnergy[] entropy[]
temperature[] density[] pressure[]
charge[] ionizationFraction[]
B_x[] B_y[] B_z[]
closureRef[] validityFlags[]
```

Avoid object-per-particle GPU layouts.

---

## 23. Adaptive refinement and scale bridges

The graph is universal because the bridge contracts are universal, not because every scale runs every law everywhere.

Bridge examples:

```text
quantum state -> interatomic potential
quantum response -> optical/opacity closure
quantum spectrum -> statistical ensemble
atomistic MD -> diffusion/viscosity/surface tension
microstructure -> elastic/fracture closure
carrier plasma -> MHD-like large-scale fields
nuclear network -> heat/neutrino/source terms
Newtonian gravity -> post-Newtonian/GR escalation when compact
```

```ts
export interface ScaleBridgeNode {
  id: string;
  fromScale: string;
  toScale: string;
  operation:
    | "coarse_grain"
    | "refine"
    | "homogenize"
    | "statistical_ensemble"
    | "response_derivative"
    | "closure_infer"
    | "subgrid_model"
    | "regime_escalation"
    | "decoherence_bridge";
  inputs: StateRef[];
  outputs: StateRef[];
  errorEstimator: ErrorEstimatorSpec;
  triggerPolicy: RefinementTriggerSpec;
}
```

---

## 24. Validation

Validation is mandatory because PeerCompute peers are heterogeneous and WebGPU floating point is not bit-identical across all contexts.

Validation modes:

```text
single-authority:
  fastest, least robust

quorum:
  multiple peers compute same task; compare residuals within tolerance

spot-check:
  validators recompute random tiles or reduced reference tasks

invariant audit:
  mass, charge, baryon number, lepton number, energy, momentum, ∇·B, probability normalization

entropy audit:
  irreversible closures must not silently erase entropy accounting

provenance audit:
  closures must trace back to quantum/statistical/nuclear/gravity tasks
```

Important: floating state should be validated by tolerances and physical residuals, not byte-identical hashes alone.

---

## 25. Acceptance tests

A serious MVP should pass these tests in sequence.

### 25.1 Atomic / quantum tests

```text
hydrogen atom ground-state energy in exact-small tier
H2 bond curve from electronic solve
simple harmonic oscillator / particle-in-box validation
Hellmann-Feynman force consistency
finite-difference stress/strain derivative consistency
```

### 25.2 Statistical tests

```text
Maxwell-Boltzmann gas pressure in classical limit
Fermi-Dirac electron degeneracy pressure in dense limit
Bose-Einstein photon/phonon occupancy test
Saha hydrogen ionization in LTE regime
Planck spectrum / blackbody radiation sanity test
```

### 25.3 Material property tests

```text
elastic tensor from energy/free-energy strain derivatives
phonon frequencies for simple lattice
thermal expansion from free-energy minimum vs temperature
optical absorption from transition strengths in a toy system
diffusion from atomistic trajectory statistics
```

### 25.4 Fluid / phase tests

```text
droplet formation from repulsion/cohesion/thermal carriers
surface behavior from density/free-energy gradient
freezing/melting with latent heat accounting
crystal nucleation and defect formation in a cooling melt
```

### 25.5 Star tests

```text
self-gravitating hydrogen cloud collapses and heats
pressure response halts or slows collapse in valid conditions
ionization fraction follows LTE/non-LTE selector
fusion source activates only in hot dense valid region
radiation/opacity transports energy outward
hydrostatic-like balance emerges in stable regime
```

### 25.6 Magnetic tests

```text
zero B + no battery remains zero
seed B + rotating/conductive plasma amplifies under dynamo-favorable conditions
∇·B remains controlled
Lorentz backreaction saturates growth
```

### 25.7 Relativistic tests

```text
Newtonian solver rejected when compactness exceeds envelope
relativistic electron degeneracy changes high-density EOS
TOV benchmark for static compact object tier
fixed-metric geodesic/radiation path sanity test
```

---

## 26. MVP build order

Do not start with black holes or full DFT.

### Stage 0: Runtime skeleton

```text
StateNode
CarrierState
LawNode
ClosureRef
ValidityEnvelope
ScaleBridgeNode
TaskCapsule
ProvenanceReport
```

### Stage 1: WebGPU carrier kernel set

```text
spatial hash
neighbor edges
edge messages
accumulation
symplectic integration
constraint projection
coarse observers
compact deltas
```

### Stage 2: First-principles micro-cache

```text
exact small Schrödinger examples
simple molecular Hamiltonian contract
Born-Oppenheimer energy surface for tiny systems
property closure provenance schema
```

### Stage 3: Statistical bridge

```text
partition function examples
Fermi-Dirac / Bose-Einstein / Maxwell-Boltzmann occupancies
Saha LTE ionization
basic EOS closure from free energy
```

### Stage 4: Liquids and crystal formation

```text
carrier liquid droplet
phase/free-energy order parameter
cooling melt to crystal
elastic response derived from microstructure/closure
```

### Stage 5: Hydrogen star core demo

```text
self-gravity
thermal ensemble pressure
ionization
simple radiation cooling
simple fusion energy source with nuclear provenance
adaptive refinement
```

### Stage 6: Stellar dynamo demo

```text
ionized plasma
seed/battery
induction
Lorentz backreaction
∇·B control
magnetic energy growth/saturation
```

### Stage 7: Relativistic/QED extensions

```text
relativistic electron EOS
opacity/radiation improvements
post-Newtonian/TOV checks
strong-field/QED warnings
fixed-metric GRMHD experiments
```

---

## 27. Explicit non-goals for early versions

Early ULG should not claim:

```text
exact full many-body Schrödinger simulation of macroscopic matter
full ab initio stellar opacity for arbitrary composition
complete DFT replacement
complete QED in browser WebGPU
validated neutron star / black hole evolution
production-grade fusion code
validated weather/CFD replacement
```

The legitimate early claim is:

```text
A PeerCompute/WebGPU law-graph runtime that lets material, fluid, stellar, magnetic, and optical behavior emerge from carrier interactions plus explicit first-principles/statistical/field/nuclear closures with provenance and validity checks.
```

That is ambitious enough without lying.

---

## 28. Bottom-line architecture statement

ULG v0.3 is a small dynamic carrier-graph runtime plus explicit root physics contracts.

The smallest viable substrate is:

```text
carriers
+ neighborhoods
+ edge messages
+ structure-preserving integration
+ coarse observers
+ topology/refinement events
+ symmetry/action contracts
+ quantum state contracts
+ quantum statistical ensemble contracts
+ field/radiation contracts
+ nuclear/weak contracts
+ spacetime/gravity contracts
+ irreversibility/decoherence contracts
+ provenance/validity contracts
```

Then:

```text
liquids emerge as coarse-grained carrier behavior
crystals emerge from interaction energy landscapes and cooling paths
material properties emerge as quantum/statistical response closures
stellar structure emerges from gravity, EOS, radiation, fusion, and transport
stellar magnetic fields emerge from plasma motion, induction, seed/battery, and backreaction
black-hole/magnetar regimes require GR/QED selectors, not Newtonian extrapolation
```

The key philosophical correction is:

> “The rest should emerge” is only true after the right substrate exists.  
> ULG’s job is to keep that substrate minimal, explicit, valid, and composable.

---

## 29. Reference anchors

These are not implementation dependencies. They are conceptual anchors for the contracts above.

- PeerCompute README: browser-based P2P compute/state architecture.  
  https://github.com/MetaverseJS/peercompute/blob/main/README.md

- WebGPU specification.  
  https://www.w3.org/TR/webgpu/

- WGSL specification.  
  https://www.w3.org/TR/WGSL/

- Hohenberg and Kohn, “Inhomogeneous Electron Gas,” Physical Review, 1964.  
  https://link.aps.org/doi/10.1103/PhysRev.136.B864

- Kohn and Sham, “Self-Consistent Equations Including Exchange and Correlation Effects,” Physical Review, 1965.  
  https://link.aps.org/doi/10.1103/PhysRev.140.A1133

- Born-Oppenheimer approximation overview.  
  https://chem.libretexts.org/Bookshelves/Physical_and_Theoretical_Chemistry_Textbook_Maps/Time_Dependent_Quantum_Mechanics_and_Spectroscopy_2014e_%28Tokmakoff%29/06%3A_Adiabatic_Approximation/6.01%3A_BornOppenheimer_Approximation

- Saha ionization equation overview.  
  https://en.wikipedia.org/wiki/Saha_ionization_equation

- Tolman-Oppenheimer-Volkoff equation overview.  
  https://en.wikipedia.org/wiki/Tolman%E2%80%93Oppenheimer%E2%80%93Volkoff_equation

- NASA solar dynamo explanation.  
  https://solarscience.msfc.nasa.gov/dynamo.shtml
